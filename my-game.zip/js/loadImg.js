$(document).ready(function () {
    $('img').on('load', function () {
        // Do something when the image loads
    });
});